--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE trainium;
--
-- Name: trainium; Type: DATABASE; Schema: -; Owner: trainium_user
--

CREATE DATABASE trainium WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE trainium OWNER TO trainium_user;

\connect trainium

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: enforce_single_active_resume(); Type: FUNCTION; Schema: public; Owner: trainium_user
--

CREATE FUNCTION public.enforce_single_active_resume() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  -- If the new row is being set to active...
  IF NEW.is_active THEN
    -- Deactivate all other resumes
    UPDATE public.resumes
    SET is_active = false
    WHERE is_active = true
      AND resume_id <> NEW.resume_id;
  END IF;

  RETURN NEW;
END;
$$;


ALTER FUNCTION public.enforce_single_active_resume() OWNER TO trainium_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: interviews; Type: TABLE; Schema: public; Owner: trainium_user
--

CREATE TABLE public.interviews (
    interview_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    job_application_id uuid NOT NULL,
    interview_date timestamp with time zone,
    interview_type text NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    ai_prep_data jsonb
);


ALTER TABLE public.interviews OWNER TO trainium_user;

--
-- Name: save_interview_with_contacts(uuid, uuid, text, text, text, jsonb, uuid[]); Type: FUNCTION; Schema: public; Owner: trainium_user
--

CREATE FUNCTION public.save_interview_with_contacts(p_interview_id uuid, p_job_application_id uuid, p_interview_date text, p_interview_type text, p_notes text, p_ai_prep_data jsonb, p_contact_ids uuid[]) RETURNS public.interviews
    LANGUAGE plpgsql
    AS $$
DECLARE
    saved_interview interviews;
BEGIN
    -- Step 1: Insert or update the main interview record.
    INSERT INTO interviews (interview_id, job_application_id, interview_date, interview_type, notes, ai_prep_data)
    VALUES (COALESCE(p_interview_id, gen_random_uuid()), p_job_application_id, p_interview_date::date, p_interview_type, p_notes, p_ai_prep_data)
    ON CONFLICT (interview_id)
    DO UPDATE SET
        job_application_id = p_job_application_id,
        interview_date = p_interview_date::date, -- This line is corrected
        interview_type = p_interview_type,
        notes = p_notes,
        ai_prep_data = p_ai_prep_data
    RETURNING * INTO saved_interview;

    -- Step 2: Clear out old contacts for this interview.
    DELETE FROM interview_contacts WHERE interview_id = saved_interview.interview_id;

    -- Step 3: Insert the new list of contacts.
    IF p_contact_ids IS NOT NULL THEN
        INSERT INTO interview_contacts (interview_id, contact_id)
        SELECT saved_interview.interview_id, unnest(p_contact_ids);
    END IF;

    RETURN saved_interview;
END;
$$;


ALTER FUNCTION public.save_interview_with_contacts(p_interview_id uuid, p_job_application_id uuid, p_interview_date text, p_interview_type text, p_notes text, p_ai_prep_data jsonb, p_contact_ids uuid[]) OWNER TO trainium_user;

--
-- Name: update_timestamp(); Type: FUNCTION; Schema: public; Owner: trainium_user
--

CREATE FUNCTION public.update_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_timestamp() OWNER TO trainium_user;

--
-- Name: upsert_interview_with_contacts(uuid, text, uuid, timestamp with time zone, text, jsonb, uuid[]); Type: FUNCTION; Schema: public; Owner: trainium_user
--

CREATE FUNCTION public.upsert_interview_with_contacts(p_job_application_id uuid, p_interview_type text, p_interview_id uuid DEFAULT NULL::uuid, p_interview_date timestamp with time zone DEFAULT NULL::timestamp with time zone, p_notes text DEFAULT NULL::text, p_ai_prep_data jsonb DEFAULT NULL::jsonb, p_contact_ids uuid[] DEFAULT '{}'::uuid[]) RETURNS SETOF public.interviews
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_interview_id uuid;
BEGIN
    -- Upsert the interview record
    INSERT INTO interviews (interview_id, job_application_id, interview_date, interview_type, notes, ai_prep_data)
    VALUES (COALESCE(p_interview_id, uuid_generate_v4()), p_job_application_id, p_interview_date, p_interview_type, p_notes, p_ai_prep_data)
    ON CONFLICT (interview_id)
    DO UPDATE SET
        job_application_id = EXCLUDED.job_application_id,
        interview_date = EXCLUDED.interview_date,
        interview_type = EXCLUDED.interview_type,
        notes = EXCLUDED.notes,
        ai_prep_data = EXCLUDED.ai_prep_data
    RETURNING interviews.interview_id INTO v_interview_id;

    -- Manage the interview_contacts join table
    IF p_contact_ids IS NOT NULL THEN
        -- Delete contacts that are no longer associated
        DELETE FROM interview_contacts
        WHERE interview_id = v_interview_id AND NOT (contact_id = ANY(p_contact_ids));

        -- Insert new contacts
        INSERT INTO interview_contacts (interview_id, contact_id)
        SELECT v_interview_id, unnest_contact_id
        FROM unnest(p_contact_ids) AS unnest_contact_id
        ON CONFLICT (interview_id, contact_id) DO NOTHING;
    ELSE
        -- If an empty array or null is passed, remove all associations
        DELETE FROM interview_contacts WHERE interview_id = v_interview_id;
    END IF;

    -- Return the full interview record
    RETURN QUERY SELECT * FROM interviews WHERE interview_id = v_interview_id;
END;
$$;


ALTER FUNCTION public.upsert_interview_with_contacts(p_job_application_id uuid, p_interview_type text, p_interview_id uuid, p_interview_date timestamp with time zone, p_notes text, p_ai_prep_data jsonb, p_contact_ids uuid[]) OWNER TO trainium_user;

--
-- Name: common_interview_answers; Type: TABLE; Schema: public; Owner: trainium_user
--

CREATE TABLE public.common_interview_answers (
    answer_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    question text NOT NULL,
    answer text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    speaker_notes text
);


ALTER TABLE public.common_interview_answers OWNER TO trainium_user;

--
-- Name: companies; Type: TABLE; Schema: public; Owner: trainium_user
--

CREATE TABLE public.companies (
    company_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    company_name text NOT NULL,
    mission jsonb,
    "values" jsonb,
    news jsonb,
    goals jsonb,
    issues jsonb,
    customer_segments jsonb,
    strategic_initiatives jsonb,
    market_position jsonb,
    competitors jsonb,
    is_recruiting_firm boolean DEFAULT false,
    industry jsonb,
    company_url text
);


ALTER TABLE public.companies OWNER TO trainium_user;

--
-- Name: contacts; Type: TABLE; Schema: public; Owner: trainium_user
--

CREATE TABLE public.contacts (
    contact_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    job_title text,
    company_id uuid,
    job_application_id uuid,
    linkedin_url text,
    email text,
    status text NOT NULL,
    is_referral boolean DEFAULT false,
    date_contacted date,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    persona text,
    strategic_alignment_score numeric DEFAULT 0,
    messages jsonb,
    linkedin_about text
);


ALTER TABLE public.contacts OWNER TO trainium_user;

--
-- Name: interview_contacts; Type: TABLE; Schema: public; Owner: trainium_user
--

CREATE TABLE public.interview_contacts (
    interview_contact_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    interview_id uuid NOT NULL,
    contact_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.interview_contacts OWNER TO trainium_user;

--
-- Name: job_applications; Type: TABLE; Schema: public; Owner: trainium_user
--

CREATE TABLE public.job_applications (
    job_application_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    company_id uuid,
    status_id uuid,
    job_title text NOT NULL,
    job_description text NOT NULL,
    job_link text,
    salary text,
    location text,
    remote_status text,
    date_applied date,
    created_at timestamp with time zone DEFAULT now(),
    ai_summary text,
    job_problem_analysis_result jsonb,
    keywords jsonb,
    guidance jsonb,
    resume_summary text,
    resume_summary_bullets text,
    tailored_resume_json jsonb,
    application_questions jsonb,
    referral_target_suggestion text,
    strategic_fit_score integer,
    assumed_requirements jsonb,
    initial_interview_prep jsonb,
    keyword_coverage_score numeric,
    next_steps_plan text,
    post_submission_summary text,
    why_this_job text
);


ALTER TABLE public.job_applications OWNER TO trainium_user;

--
-- Name: linkedin_posts; Type: TABLE; Schema: public; Owner: trainium_user
--

CREATE TABLE public.linkedin_posts (
    post_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    theme text NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    variant text,
    tags text[]
);


ALTER TABLE public.linkedin_posts OWNER TO trainium_user;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: trainium_user
--

CREATE TABLE public.messages (
    message_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    contact_id uuid,
    job_application_id uuid,
    message_type text NOT NULL,
    content text NOT NULL,
    follow_up_due_date date,
    created_at timestamp with time zone DEFAULT now(),
    company_id uuid,
    response_received boolean DEFAULT false,
    message_variant text,
    ai_analysis jsonb,
    response_timestamp timestamp with time zone,
    variant text,
    is_user_sent boolean,
    CONSTRAINT chk_parent_exists CHECK (((contact_id IS NOT NULL) OR (job_application_id IS NOT NULL) OR (company_id IS NOT NULL)))
);


ALTER TABLE public.messages OWNER TO trainium_user;

--
-- Name: COLUMN messages.company_id; Type: COMMENT; Schema: public; Owner: trainium_user
--

COMMENT ON COLUMN public.messages.company_id IS 'Foreign key to the companies table for company-level engagement messages.';


--
-- Name: CONSTRAINT chk_parent_exists ON messages; Type: COMMENT; Schema: public; Owner: trainium_user
--

COMMENT ON CONSTRAINT chk_parent_exists ON public.messages IS 'Ensures that every message is associated with at least one parent (a contact, an application, or a company).';


--
-- Name: post_engagements; Type: TABLE; Schema: public; Owner: trainium_user
--

CREATE TABLE public.post_engagements (
    engagement_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    post_id uuid NOT NULL,
    engagement_type text NOT NULL,
    comment_text text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by uuid,
    updated_by uuid,
    contact_name text NOT NULL,
    contact_title text,
    interaction_type text,
    content text,
    contact_linkedin_url text,
    notes text,
    post_theme text
);


ALTER TABLE public.post_engagements OWNER TO trainium_user;

--
-- Name: post_responses; Type: TABLE; Schema: public; Owner: trainium_user
--

CREATE TABLE public.post_responses (
    comment_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    post_id uuid,
    comment_text text,
    ai_analysis jsonb,
    created_at timestamp with time zone DEFAULT now(),
    post_excerpt text NOT NULL,
    conversation jsonb
);


ALTER TABLE public.post_responses OWNER TO trainium_user;

--
-- Name: resume_accomplishments; Type: TABLE; Schema: public; Owner: trainium_user
--

CREATE TABLE public.resume_accomplishments (
    accomplishment_id uuid DEFAULT gen_random_uuid() NOT NULL,
    work_experience_id uuid,
    description text NOT NULL,
    original_description text,
    ai_optimize boolean DEFAULT false,
    always_include boolean DEFAULT false,
    score jsonb,
    themes text[],
    order_index integer DEFAULT 0,
    is_deleted boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.resume_accomplishments OWNER TO trainium_user;

--
-- Name: resume_certifications; Type: TABLE; Schema: public; Owner: trainium_user
--

CREATE TABLE public.resume_certifications (
    certification_id uuid DEFAULT gen_random_uuid() NOT NULL,
    resume_id uuid,
    name text,
    organization text,
    issued_date date,
    expiration_date date,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    link text
);


ALTER TABLE public.resume_certifications OWNER TO trainium_user;

--
-- Name: resume_education; Type: TABLE; Schema: public; Owner: trainium_user
--

CREATE TABLE public.resume_education (
    education_id uuid DEFAULT gen_random_uuid() NOT NULL,
    resume_id uuid,
    school text,
    degree text,
    major text[],
    minor text[],
    start_year smallint,
    start_month smallint,
    end_year smallint,
    end_month smallint,
    location text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.resume_education OWNER TO trainium_user;

--
-- Name: resume_skill_items; Type: TABLE; Schema: public; Owner: trainium_user
--

CREATE TABLE public.resume_skill_items (
    skill_item_id uuid DEFAULT gen_random_uuid() NOT NULL,
    skill_section_id uuid,
    item_text text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.resume_skill_items OWNER TO trainium_user;

--
-- Name: resume_skill_sections; Type: TABLE; Schema: public; Owner: trainium_user
--

CREATE TABLE public.resume_skill_sections (
    skill_section_id uuid DEFAULT gen_random_uuid() NOT NULL,
    resume_id uuid,
    heading text NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.resume_skill_sections OWNER TO trainium_user;

--
-- Name: resume_work_experience; Type: TABLE; Schema: public; Owner: trainium_user
--

CREATE TABLE public.resume_work_experience (
    work_experience_id uuid DEFAULT gen_random_uuid() NOT NULL,
    resume_id uuid,
    company_name text,
    job_title text,
    location text,
    start_date date,
    end_date date,
    is_current boolean DEFAULT false,
    is_deleted boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    filter_accomplishment_count integer DEFAULT 0
);


ALTER TABLE public.resume_work_experience OWNER TO trainium_user;

--
-- Name: resumes; Type: TABLE; Schema: public; Owner: trainium_user
--

CREATE TABLE public.resumes (
    resume_id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    resume_name text NOT NULL,
    summary_paragraph text,
    summary_bullets jsonb DEFAULT '[]'::jsonb,
    is_default boolean DEFAULT false,
    visibility text DEFAULT 'private'::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by uuid,
    updated_by uuid,
    is_locked boolean DEFAULT false,
    CONSTRAINT resumes_visibility_check CHECK ((visibility = ANY (ARRAY['private'::text, 'public'::text, 'shared'::text])))
);


ALTER TABLE public.resumes OWNER TO trainium_user;

--
-- Name: standard_job_roles; Type: TABLE; Schema: public; Owner: trainium_user
--

CREATE TABLE public.standard_job_roles (
    role_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    role_title text NOT NULL,
    role_description text,
    skills_required jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.standard_job_roles OWNER TO trainium_user;

--
-- Name: statuses; Type: TABLE; Schema: public; Owner: trainium_user
--

CREATE TABLE public.statuses (
    status_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    status_name text NOT NULL
);


ALTER TABLE public.statuses OWNER TO trainium_user;

--
-- Name: user_positioning_profiles; Type: TABLE; Schema: public; Owner: trainium_user
--

CREATE TABLE public.user_positioning_profiles (
    profile_id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    desired_title text NOT NULL,
    desired_industry text,
    desired_company_stage text,
    mission_alignment text,
    long_term_legacy text,
    positioning_statement text,
    key_strengths text[],
    signature_capability text,
    impact_story_title text,
    impact_story_body text,
    representative_metrics text[],
    leadership_style text,
    communication_style text,
    working_preferences text[],
    preferred_locations text[],
    relocation_open boolean DEFAULT false,
    compensation_expectation text,
    linkedin_url text,
    personal_website text,
    github_or_portfolio text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    default_resume_id uuid,
    user_positioning_profiles text[],
    user_id uuid,
    positioning_summary text,
    core_narrative text,
    highlight_1 text,
    highlight_2 text,
    highlight_3 text,
    highlight_4 text,
    effectiveness_statement text,
    connection_invite_prompt text
);


ALTER TABLE public.user_positioning_profiles OWNER TO trainium_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: trainium_user
--

CREATE TABLE public.users (
    user_id uuid DEFAULT gen_random_uuid() NOT NULL,
    first_name text,
    last_name text,
    email text,
    phone_number text,
    city text,
    state text,
    links text[],
    username text,
    profile_image_url text,
    timezone text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.users OWNER TO trainium_user;

--
-- Data for Name: common_interview_answers; Type: TABLE DATA; Schema: public; Owner: trainium_user
--

COPY public.common_interview_answers (answer_id, user_id, question, answer, created_at, updated_at, speaker_notes) FROM stdin;
\.
COPY public.common_interview_answers (answer_id, user_id, question, answer, created_at, updated_at, speaker_notes) FROM '$$PATH$$/3706.dat';

--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: trainium_user
--

COPY public.companies (company_id, company_name, mission, "values", news, goals, issues, customer_segments, strategic_initiatives, market_position, competitors, is_recruiting_firm, industry, company_url) FROM stdin;
\.
COPY public.companies (company_id, company_name, mission, "values", news, goals, issues, customer_segments, strategic_initiatives, market_position, competitors, is_recruiting_firm, industry, company_url) FROM '$$PATH$$/3686.dat';

--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: trainium_user
--

COPY public.contacts (contact_id, first_name, last_name, job_title, company_id, job_application_id, linkedin_url, email, status, is_referral, date_contacted, notes, created_at, persona, strategic_alignment_score, messages, linkedin_about) FROM stdin;
\.
COPY public.contacts (contact_id, first_name, last_name, job_title, company_id, job_application_id, linkedin_url, email, status, is_referral, date_contacted, notes, created_at, persona, strategic_alignment_score, messages, linkedin_about) FROM '$$PATH$$/3689.dat';

--
-- Data for Name: interview_contacts; Type: TABLE DATA; Schema: public; Owner: trainium_user
--

COPY public.interview_contacts (interview_contact_id, interview_id, contact_id, created_at) FROM stdin;
\.
COPY public.interview_contacts (interview_contact_id, interview_id, contact_id, created_at) FROM '$$PATH$$/3697.dat';

--
-- Data for Name: interviews; Type: TABLE DATA; Schema: public; Owner: trainium_user
--

COPY public.interviews (interview_id, job_application_id, interview_date, interview_type, notes, created_at, ai_prep_data) FROM stdin;
\.
COPY public.interviews (interview_id, job_application_id, interview_date, interview_type, notes, created_at, ai_prep_data) FROM '$$PATH$$/3691.dat';

--
-- Data for Name: job_applications; Type: TABLE DATA; Schema: public; Owner: trainium_user
--

COPY public.job_applications (job_application_id, company_id, status_id, job_title, job_description, job_link, salary, location, remote_status, date_applied, created_at, ai_summary, job_problem_analysis_result, keywords, guidance, resume_summary, resume_summary_bullets, tailored_resume_json, application_questions, referral_target_suggestion, strategic_fit_score, assumed_requirements, initial_interview_prep, keyword_coverage_score, next_steps_plan, post_submission_summary, why_this_job) FROM stdin;
\.
COPY public.job_applications (job_application_id, company_id, status_id, job_title, job_description, job_link, salary, location, remote_status, date_applied, created_at, ai_summary, job_problem_analysis_result, keywords, guidance, resume_summary, resume_summary_bullets, tailored_resume_json, application_questions, referral_target_suggestion, strategic_fit_score, assumed_requirements, initial_interview_prep, keyword_coverage_score, next_steps_plan, post_submission_summary, why_this_job) FROM '$$PATH$$/3688.dat';

--
-- Data for Name: linkedin_posts; Type: TABLE DATA; Schema: public; Owner: trainium_user
--

COPY public.linkedin_posts (post_id, theme, content, created_at, variant, tags) FROM stdin;
\.
COPY public.linkedin_posts (post_id, theme, content, created_at, variant, tags) FROM '$$PATH$$/3692.dat';

--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: trainium_user
--

COPY public.messages (message_id, contact_id, job_application_id, message_type, content, follow_up_due_date, created_at, company_id, response_received, message_variant, ai_analysis, response_timestamp, variant, is_user_sent) FROM stdin;
\.
COPY public.messages (message_id, contact_id, job_application_id, message_type, content, follow_up_due_date, created_at, company_id, response_received, message_variant, ai_analysis, response_timestamp, variant, is_user_sent) FROM '$$PATH$$/3690.dat';

--
-- Data for Name: post_engagements; Type: TABLE DATA; Schema: public; Owner: trainium_user
--

COPY public.post_engagements (engagement_id, post_id, engagement_type, comment_text, created_at, updated_at, created_by, updated_by, contact_name, contact_title, interaction_type, content, contact_linkedin_url, notes, post_theme) FROM stdin;
\.
COPY public.post_engagements (engagement_id, post_id, engagement_type, comment_text, created_at, updated_at, created_by, updated_by, contact_name, contact_title, interaction_type, content, contact_linkedin_url, notes, post_theme) FROM '$$PATH$$/3695.dat';

--
-- Data for Name: post_responses; Type: TABLE DATA; Schema: public; Owner: trainium_user
--

COPY public.post_responses (comment_id, post_id, comment_text, ai_analysis, created_at, post_excerpt, conversation) FROM stdin;
\.
COPY public.post_responses (comment_id, post_id, comment_text, ai_analysis, created_at, post_excerpt, conversation) FROM '$$PATH$$/3694.dat';

--
-- Data for Name: resume_accomplishments; Type: TABLE DATA; Schema: public; Owner: trainium_user
--

COPY public.resume_accomplishments (accomplishment_id, work_experience_id, description, original_description, ai_optimize, always_include, score, themes, order_index, is_deleted, created_at, updated_at) FROM stdin;
\.
COPY public.resume_accomplishments (accomplishment_id, work_experience_id, description, original_description, ai_optimize, always_include, score, themes, order_index, is_deleted, created_at, updated_at) FROM '$$PATH$$/3704.dat';

--
-- Data for Name: resume_certifications; Type: TABLE DATA; Schema: public; Owner: trainium_user
--

COPY public.resume_certifications (certification_id, resume_id, name, organization, issued_date, expiration_date, created_at, updated_at, link) FROM stdin;
\.
COPY public.resume_certifications (certification_id, resume_id, name, organization, issued_date, expiration_date, created_at, updated_at, link) FROM '$$PATH$$/3705.dat';

--
-- Data for Name: resume_education; Type: TABLE DATA; Schema: public; Owner: trainium_user
--

COPY public.resume_education (education_id, resume_id, school, degree, major, minor, start_year, start_month, end_year, end_month, location, created_at, updated_at) FROM stdin;
\.
COPY public.resume_education (education_id, resume_id, school, degree, major, minor, start_year, start_month, end_year, end_month, location, created_at, updated_at) FROM '$$PATH$$/3702.dat';

--
-- Data for Name: resume_skill_items; Type: TABLE DATA; Schema: public; Owner: trainium_user
--

COPY public.resume_skill_items (skill_item_id, skill_section_id, item_text, created_at, updated_at) FROM stdin;
\.
COPY public.resume_skill_items (skill_item_id, skill_section_id, item_text, created_at, updated_at) FROM '$$PATH$$/3701.dat';

--
-- Data for Name: resume_skill_sections; Type: TABLE DATA; Schema: public; Owner: trainium_user
--

COPY public.resume_skill_sections (skill_section_id, resume_id, heading, created_at, updated_at) FROM stdin;
\.
COPY public.resume_skill_sections (skill_section_id, resume_id, heading, created_at, updated_at) FROM '$$PATH$$/3700.dat';

--
-- Data for Name: resume_work_experience; Type: TABLE DATA; Schema: public; Owner: trainium_user
--

COPY public.resume_work_experience (work_experience_id, resume_id, company_name, job_title, location, start_date, end_date, is_current, is_deleted, created_at, updated_at, filter_accomplishment_count) FROM stdin;
\.
COPY public.resume_work_experience (work_experience_id, resume_id, company_name, job_title, location, start_date, end_date, is_current, is_deleted, created_at, updated_at, filter_accomplishment_count) FROM '$$PATH$$/3703.dat';

--
-- Data for Name: resumes; Type: TABLE DATA; Schema: public; Owner: trainium_user
--

COPY public.resumes (resume_id, user_id, resume_name, summary_paragraph, summary_bullets, is_default, visibility, created_at, updated_at, created_by, updated_by, is_locked) FROM stdin;
\.
COPY public.resumes (resume_id, user_id, resume_name, summary_paragraph, summary_bullets, is_default, visibility, created_at, updated_at, created_by, updated_by, is_locked) FROM '$$PATH$$/3699.dat';

--
-- Data for Name: standard_job_roles; Type: TABLE DATA; Schema: public; Owner: trainium_user
--

COPY public.standard_job_roles (role_id, role_title, role_description, skills_required, created_at, updated_at) FROM stdin;
\.
COPY public.standard_job_roles (role_id, role_title, role_description, skills_required, created_at, updated_at) FROM '$$PATH$$/3696.dat';

--
-- Data for Name: statuses; Type: TABLE DATA; Schema: public; Owner: trainium_user
--

COPY public.statuses (status_id, status_name) FROM stdin;
\.
COPY public.statuses (status_id, status_name) FROM '$$PATH$$/3687.dat';

--
-- Data for Name: user_positioning_profiles; Type: TABLE DATA; Schema: public; Owner: trainium_user
--

COPY public.user_positioning_profiles (profile_id, desired_title, desired_industry, desired_company_stage, mission_alignment, long_term_legacy, positioning_statement, key_strengths, signature_capability, impact_story_title, impact_story_body, representative_metrics, leadership_style, communication_style, working_preferences, preferred_locations, relocation_open, compensation_expectation, linkedin_url, personal_website, github_or_portfolio, created_at, updated_at, default_resume_id, user_positioning_profiles, user_id, positioning_summary, core_narrative, highlight_1, highlight_2, highlight_3, highlight_4, effectiveness_statement, connection_invite_prompt) FROM stdin;
\.
COPY public.user_positioning_profiles (profile_id, desired_title, desired_industry, desired_company_stage, mission_alignment, long_term_legacy, positioning_statement, key_strengths, signature_capability, impact_story_title, impact_story_body, representative_metrics, leadership_style, communication_style, working_preferences, preferred_locations, relocation_open, compensation_expectation, linkedin_url, personal_website, github_or_portfolio, created_at, updated_at, default_resume_id, user_positioning_profiles, user_id, positioning_summary, core_narrative, highlight_1, highlight_2, highlight_3, highlight_4, effectiveness_statement, connection_invite_prompt) FROM '$$PATH$$/3693.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: trainium_user
--

COPY public.users (user_id, first_name, last_name, email, phone_number, city, state, links, username, profile_image_url, timezone, created_at, updated_at) FROM stdin;
\.
COPY public.users (user_id, first_name, last_name, email, phone_number, city, state, links, username, profile_image_url, timezone, created_at, updated_at) FROM '$$PATH$$/3698.dat';

--
-- Name: common_interview_answers common_interview_answers_pkey; Type: CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.common_interview_answers
    ADD CONSTRAINT common_interview_answers_pkey PRIMARY KEY (answer_id);


--
-- Name: companies companies_company_name_key; Type: CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_company_name_key UNIQUE (company_name);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (company_id);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (contact_id);


--
-- Name: interview_contacts interview_contacts_interview_id_contact_id_key; Type: CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.interview_contacts
    ADD CONSTRAINT interview_contacts_interview_id_contact_id_key UNIQUE (interview_id, contact_id);


--
-- Name: interview_contacts interview_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.interview_contacts
    ADD CONSTRAINT interview_contacts_pkey PRIMARY KEY (interview_contact_id);


--
-- Name: interviews interviews_pkey; Type: CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.interviews
    ADD CONSTRAINT interviews_pkey PRIMARY KEY (interview_id);


--
-- Name: job_applications job_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.job_applications
    ADD CONSTRAINT job_applications_pkey PRIMARY KEY (job_application_id);


--
-- Name: linkedin_posts linkedin_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.linkedin_posts
    ADD CONSTRAINT linkedin_posts_pkey PRIMARY KEY (post_id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (message_id);


--
-- Name: post_engagements post_engagements_pkey; Type: CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.post_engagements
    ADD CONSTRAINT post_engagements_pkey PRIMARY KEY (engagement_id);


--
-- Name: post_responses post_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.post_responses
    ADD CONSTRAINT post_responses_pkey PRIMARY KEY (comment_id);


--
-- Name: resume_accomplishments resume_accomplishments_pkey; Type: CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.resume_accomplishments
    ADD CONSTRAINT resume_accomplishments_pkey PRIMARY KEY (accomplishment_id);


--
-- Name: resume_certifications resume_certifications_pkey; Type: CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.resume_certifications
    ADD CONSTRAINT resume_certifications_pkey PRIMARY KEY (certification_id);


--
-- Name: resume_education resume_education_pkey; Type: CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.resume_education
    ADD CONSTRAINT resume_education_pkey PRIMARY KEY (education_id);


--
-- Name: resume_skill_items resume_skill_items_pkey; Type: CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.resume_skill_items
    ADD CONSTRAINT resume_skill_items_pkey PRIMARY KEY (skill_item_id);


--
-- Name: resume_skill_items resume_skill_items_skill_section_id_item_text_key; Type: CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.resume_skill_items
    ADD CONSTRAINT resume_skill_items_skill_section_id_item_text_key UNIQUE (skill_section_id, item_text);


--
-- Name: resume_skill_sections resume_skill_sections_pkey; Type: CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.resume_skill_sections
    ADD CONSTRAINT resume_skill_sections_pkey PRIMARY KEY (skill_section_id);


--
-- Name: resume_work_experience resume_work_experience_pkey; Type: CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.resume_work_experience
    ADD CONSTRAINT resume_work_experience_pkey PRIMARY KEY (work_experience_id);


--
-- Name: resumes resumes_pkey; Type: CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.resumes
    ADD CONSTRAINT resumes_pkey PRIMARY KEY (resume_id);


--
-- Name: standard_job_roles standard_job_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.standard_job_roles
    ADD CONSTRAINT standard_job_roles_pkey PRIMARY KEY (role_id);


--
-- Name: standard_job_roles standard_job_roles_title_key; Type: CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.standard_job_roles
    ADD CONSTRAINT standard_job_roles_title_key UNIQUE (role_title);


--
-- Name: statuses statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.statuses
    ADD CONSTRAINT statuses_pkey PRIMARY KEY (status_id);


--
-- Name: statuses statuses_status_name_key; Type: CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.statuses
    ADD CONSTRAINT statuses_status_name_key UNIQUE (status_name);


--
-- Name: user_positioning_profiles user_positioning_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.user_positioning_profiles
    ADD CONSTRAINT user_positioning_profiles_pkey PRIMARY KEY (profile_id);


--
-- Name: user_positioning_profiles user_positioning_profiles_user_id_key; Type: CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.user_positioning_profiles
    ADD CONSTRAINT user_positioning_profiles_user_id_key UNIQUE (user_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_common_interview_answers_user_id; Type: INDEX; Schema: public; Owner: trainium_user
--

CREATE INDEX idx_common_interview_answers_user_id ON public.common_interview_answers USING btree (user_id);


--
-- Name: idx_contacts_company_id; Type: INDEX; Schema: public; Owner: trainium_user
--

CREATE INDEX idx_contacts_company_id ON public.contacts USING btree (company_id);


--
-- Name: idx_contacts_job_application_id; Type: INDEX; Schema: public; Owner: trainium_user
--

CREATE INDEX idx_contacts_job_application_id ON public.contacts USING btree (job_application_id);


--
-- Name: idx_interviews_job_application_id; Type: INDEX; Schema: public; Owner: trainium_user
--

CREATE INDEX idx_interviews_job_application_id ON public.interviews USING btree (job_application_id);


--
-- Name: idx_job_applications_company_id; Type: INDEX; Schema: public; Owner: trainium_user
--

CREATE INDEX idx_job_applications_company_id ON public.job_applications USING btree (company_id);


--
-- Name: idx_job_applications_status_id; Type: INDEX; Schema: public; Owner: trainium_user
--

CREATE INDEX idx_job_applications_status_id ON public.job_applications USING btree (status_id);


--
-- Name: idx_messages_contact_id; Type: INDEX; Schema: public; Owner: trainium_user
--

CREATE INDEX idx_messages_contact_id ON public.messages USING btree (contact_id);


--
-- Name: idx_messages_job_application_id; Type: INDEX; Schema: public; Owner: trainium_user
--

CREATE INDEX idx_messages_job_application_id ON public.messages USING btree (job_application_id);


--
-- Name: idx_resumes_user_id; Type: INDEX; Schema: public; Owner: trainium_user
--

CREATE INDEX idx_resumes_user_id ON public.resumes USING btree (user_id);


--
-- Name: post_engagements set_timestamp_post_engagements; Type: TRIGGER; Schema: public; Owner: trainium_user
--

CREATE TRIGGER set_timestamp_post_engagements BEFORE UPDATE ON public.post_engagements FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: resume_accomplishments set_timestamp_resume_accomplishments; Type: TRIGGER; Schema: public; Owner: trainium_user
--

CREATE TRIGGER set_timestamp_resume_accomplishments BEFORE UPDATE ON public.resume_accomplishments FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: resume_certifications set_timestamp_resume_certifications; Type: TRIGGER; Schema: public; Owner: trainium_user
--

CREATE TRIGGER set_timestamp_resume_certifications BEFORE UPDATE ON public.resume_certifications FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: resume_education set_timestamp_resume_education; Type: TRIGGER; Schema: public; Owner: trainium_user
--

CREATE TRIGGER set_timestamp_resume_education BEFORE UPDATE ON public.resume_education FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: resume_skill_items set_timestamp_resume_skill_items; Type: TRIGGER; Schema: public; Owner: trainium_user
--

CREATE TRIGGER set_timestamp_resume_skill_items BEFORE UPDATE ON public.resume_skill_items FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: resume_skill_sections set_timestamp_resume_skill_sections; Type: TRIGGER; Schema: public; Owner: trainium_user
--

CREATE TRIGGER set_timestamp_resume_skill_sections BEFORE UPDATE ON public.resume_skill_sections FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: resume_work_experience set_timestamp_resume_work_experience; Type: TRIGGER; Schema: public; Owner: trainium_user
--

CREATE TRIGGER set_timestamp_resume_work_experience BEFORE UPDATE ON public.resume_work_experience FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: resumes set_timestamp_resumes; Type: TRIGGER; Schema: public; Owner: trainium_user
--

CREATE TRIGGER set_timestamp_resumes BEFORE UPDATE ON public.resumes FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: users set_timestamp_users; Type: TRIGGER; Schema: public; Owner: trainium_user
--

CREATE TRIGGER set_timestamp_users BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: common_interview_answers common_interview_answers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.common_interview_answers
    ADD CONSTRAINT common_interview_answers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.user_positioning_profiles(user_id) ON DELETE CASCADE;


--
-- Name: contacts contacts_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(company_id) ON DELETE SET NULL;


--
-- Name: contacts contacts_job_application_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_job_application_id_fkey FOREIGN KEY (job_application_id) REFERENCES public.job_applications(job_application_id) ON DELETE SET NULL;


--
-- Name: messages fk_messages_to_companies; Type: FK CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT fk_messages_to_companies FOREIGN KEY (company_id) REFERENCES public.companies(company_id) ON DELETE SET NULL;


--
-- Name: users fk_user_profile; Type: FK CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_user_profile FOREIGN KEY (user_id) REFERENCES public.user_positioning_profiles(user_id) ON DELETE CASCADE DEFERRABLE;


--
-- Name: interview_contacts interview_contacts_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.interview_contacts
    ADD CONSTRAINT interview_contacts_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contacts(contact_id) ON DELETE CASCADE;


--
-- Name: interview_contacts interview_contacts_interview_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.interview_contacts
    ADD CONSTRAINT interview_contacts_interview_id_fkey FOREIGN KEY (interview_id) REFERENCES public.interviews(interview_id) ON DELETE CASCADE;


--
-- Name: interviews interviews_job_application_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.interviews
    ADD CONSTRAINT interviews_job_application_id_fkey FOREIGN KEY (job_application_id) REFERENCES public.job_applications(job_application_id) ON DELETE CASCADE;


--
-- Name: job_applications job_applications_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.job_applications
    ADD CONSTRAINT job_applications_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(company_id) ON DELETE SET NULL;


--
-- Name: job_applications job_applications_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.job_applications
    ADD CONSTRAINT job_applications_status_id_fkey FOREIGN KEY (status_id) REFERENCES public.statuses(status_id) ON DELETE SET NULL;


--
-- Name: messages messages_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contacts(contact_id) ON DELETE CASCADE;


--
-- Name: messages messages_job_application_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_job_application_id_fkey FOREIGN KEY (job_application_id) REFERENCES public.job_applications(job_application_id) ON DELETE CASCADE;


--
-- Name: post_engagements post_engagements_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.post_engagements
    ADD CONSTRAINT post_engagements_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.linkedin_posts(post_id) ON DELETE CASCADE;


--
-- Name: post_responses post_responses_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.post_responses
    ADD CONSTRAINT post_responses_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.linkedin_posts(post_id) ON DELETE CASCADE;


--
-- Name: resume_accomplishments resume_accomplishments_work_experience_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.resume_accomplishments
    ADD CONSTRAINT resume_accomplishments_work_experience_id_fkey FOREIGN KEY (work_experience_id) REFERENCES public.resume_work_experience(work_experience_id) ON DELETE CASCADE;


--
-- Name: resume_certifications resume_certifications_resume_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.resume_certifications
    ADD CONSTRAINT resume_certifications_resume_id_fkey FOREIGN KEY (resume_id) REFERENCES public.resumes(resume_id) ON DELETE CASCADE;


--
-- Name: resume_education resume_education_resume_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.resume_education
    ADD CONSTRAINT resume_education_resume_id_fkey FOREIGN KEY (resume_id) REFERENCES public.resumes(resume_id) ON DELETE CASCADE;


--
-- Name: resume_skill_items resume_skill_items_skill_section_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.resume_skill_items
    ADD CONSTRAINT resume_skill_items_skill_section_id_fkey FOREIGN KEY (skill_section_id) REFERENCES public.resume_skill_sections(skill_section_id) ON DELETE CASCADE;


--
-- Name: resume_skill_sections resume_skill_sections_resume_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.resume_skill_sections
    ADD CONSTRAINT resume_skill_sections_resume_id_fkey FOREIGN KEY (resume_id) REFERENCES public.resumes(resume_id) ON DELETE CASCADE;


--
-- Name: resume_work_experience resume_work_experience_resume_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.resume_work_experience
    ADD CONSTRAINT resume_work_experience_resume_id_fkey FOREIGN KEY (resume_id) REFERENCES public.resumes(resume_id) ON DELETE CASCADE;


--
-- Name: resumes resumes_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.resumes
    ADD CONSTRAINT resumes_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(user_id);


--
-- Name: resumes resumes_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.resumes
    ADD CONSTRAINT resumes_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(user_id);


--
-- Name: resumes resumes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.resumes
    ADD CONSTRAINT resumes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: user_positioning_profiles user_positioning_profiles_default_resume_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.user_positioning_profiles
    ADD CONSTRAINT user_positioning_profiles_default_resume_id_fkey FOREIGN KEY (default_resume_id) REFERENCES public.resumes(resume_id) ON DELETE SET NULL;


--
-- Name: user_positioning_profiles user_positioning_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: trainium_user
--

ALTER TABLE ONLY public.user_positioning_profiles
    ADD CONSTRAINT user_positioning_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

